//
//  AppDelegate.h
//  SqliteDemo
//
//  Created by ihefe26 on 14/10/31.
//  Copyright (c) 2014年 ihefe26. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

