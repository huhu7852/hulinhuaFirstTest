//
//  ViewController.m
//  SqliteDemo
//
//  Created by ihefe26 on 14/10/31.
//  Copyright (c) 2014年 ihefe26. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _phoneText.delegate = self;
    _addressText.delegate = self;
    _nameText.delegate = self;
    
    NSString *docsDir;
    NSArray *dirPaths;
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSLog(@"dirPaths = %@",dirPaths);
    
    docsDir = [dirPaths objectAtIndex:0];
    
         // Build the path to the database file
    databasePath = [[NSString alloc] initWithString: [docsDir stringByAppendingPathComponent: @"contacts.sqlite"]];
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    if ([filemgr fileExistsAtPath:databasePath] == NO)
    {
        const char *dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &contactDB)==SQLITE_OK)
        {
            char *errMsg;
            const char *sql_stmt = "CREATE TABLE IF NOT EXISTS CONTACTS(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, ADDRESS TEXT,PHONE TEXT)";
            if (sqlite3_exec(contactDB, sql_stmt, NULL, NULL, &errMsg)!=SQLITE_OK)
             {
              
                 NSLog(@"创建表失败");
             }
        }
        else
        {
            NSLog(@"创建/打开数据库失败");
        }
    }

}

- (IBAction)SaveToDataBase:(id)sender
{
    sqlite3_stmt *statement;
    
    const char *dbpath = [databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &contactDB)==SQLITE_OK) {
                 NSString *insertSQL = [NSString stringWithFormat:@"INSERT INTO CONTACTS (name,address,phone) VALUES(\"%@\",\"%@\",\"%@\")",_nameText.text,_addressText.text,_phoneText.text];
                 const char *insert_stmt = [insertSQL UTF8String];
                sqlite3_prepare_v2(contactDB, insert_stmt, -1, &statement, NULL);
                 if (sqlite3_step(statement)==SQLITE_DONE) {
                     NSLog(@"成功存入数据！");
                     _nameText.text = @"";
                     _phoneText.text = @"";
                     _addressText.text = @"";
                     }
                else
                    {
                        NSLog(@"存入数据失败！");
                    }
                 sqlite3_finalize(statement);
                 sqlite3_close(contactDB);
             }
}
- (IBAction)SearchFromDataBase:(id)sender
{
    const char *dbpath = [databasePath UTF8String];
    sqlite3_stmt *statement;
    if (sqlite3_open(dbpath, &contactDB) == SQLITE_OK)
    {
       NSString *querySQL = [NSString stringWithFormat:@"SELECT address,phone from contacts where name=\"%@\"",_nameText.text];
       const char *query_stmt = [querySQL UTF8String];
      if (sqlite3_prepare_v2(contactDB, query_stmt, -1, &statement, NULL) == SQLITE_OK)
      {
            if (sqlite3_step(statement) == SQLITE_ROW)
            {
                  NSString *addressField = [[NSString alloc] initWithUTF8String:(const char *)sqlite3_column_text(statement, 0)];
                   _addressText.text = addressField;
                            
                    NSString *phoneField = [[NSString alloc] initWithUTF8String:(const char *)sqlite3_column_text(statement, 1    )];
                    _phoneText.text = phoneField;
                            
                NSLog(@"查询成功");
                
             }
            else {
                NSLog(@"没有查询到数据");
                 }
            sqlite3_finalize(statement);
            }
            
            sqlite3_close(contactDB);
       }
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGRect frame = textField.frame;
    int offset = frame.origin.y + 32 - (self.view.frame.size.height - 350.0);
    
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    
    if(offset > 0)
        self.view.frame = CGRectMake(0.0f, -offset, self.view.frame.size.width, self.view.frame.size.height);
    
    [UIView commitAnimations];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


-(void)textFieldDidEndEditing:(UITextField *)textField
{
    self.view.frame =CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.phoneText resignFirstResponder];
    [self.addressText resignFirstResponder];
    [self.nameText resignFirstResponder];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
