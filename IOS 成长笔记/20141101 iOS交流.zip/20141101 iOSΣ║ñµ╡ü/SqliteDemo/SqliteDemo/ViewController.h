//
//  ViewController.h
//  SqliteDemo
//
//  Created by ihefe26 on 14/10/31.
//  Copyright (c) 2014年 ihefe26. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface ViewController : UIViewController<UITextFieldDelegate>
{
    sqlite3 *contactDB;
    NSString *databasePath;
}


@property (weak, nonatomic) IBOutlet UITextField *nameText;
@property (weak, nonatomic) IBOutlet UITextField *phoneText;
@property (weak, nonatomic) IBOutlet UITextField *addressText;
- (IBAction)SaveToDataBase:(id)sender;
- (IBAction)SearchFromDataBase:(id)sender;

@end

