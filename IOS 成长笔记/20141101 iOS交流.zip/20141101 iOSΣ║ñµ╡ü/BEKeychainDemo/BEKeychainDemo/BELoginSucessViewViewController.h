//
//  BELoginSucessViewViewController.h
//  BEKeychainDemo
//
//  Created by 张良 on 14-11-1.
//  Copyright (c) 2014年 张良. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BEKeyChain.h"
#import "ViewController.h"

@interface BELoginSucessViewViewController : UIViewController
- (IBAction)loginOUt:(id)sender;

@end
